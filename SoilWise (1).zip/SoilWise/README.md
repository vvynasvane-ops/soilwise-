# SoilWise (Java + XML, native Android)

Requirements: JDK 17, Android SDK (API 34 platform + build-tools), internet for first Gradle sync.

## Setup (Windows, from this folder)
1. Edit `local.properties` if your SDK path differs.
2. AI: open the app -> Settings -> pick a provider, type or browse a model, paste the key.
   Supported: Gemini, OpenAI, Anthropic Claude, Groq, OpenRouter, Mistral, DeepSeek, xAI, or any
   OpenAI-compatible URL (Custom). Model names are free text, so every current/future version works.
   Optional: `secrets.properties` (GEMINI_API_KEY / GEMINI_MODEL) still seeds Gemini defaults.
3. Build:
       gradlew.bat clean assembleDebug
   or run `clean_build.bat` (stops daemon, wipes build caches, rebuilds).
   APK: app\build\outputs\apk\debug\app-debug.apk
4. If gradle-wrapper.jar is missing/corrupt, run `setup_wrapper.bat` (same curl as v8.10.2).

## Versions (known-compatible set)
Gradle 8.10.2 | Android Gradle Plugin 8.5.2 | compileSdk/targetSdk 34 | minSdk 24 | Java 17
AppCompat 1.7.0 | Material 1.12.0 (only two dependencies)

## What is inside
Analyze soil (camera/gallery -> Gemini), Weather & planting (GPS/manual + Open-Meteo, no key needed),
Soil advisor chat, Farm news (RSS + AI summary), History, Settings (Blue/Green/Earth themes, light/dark/system).
No Firebase / Google Play services: nothing to configure beyond the Gemini key.
