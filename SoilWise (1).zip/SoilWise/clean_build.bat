@echo off
setlocal
cd /d "%~dp0"
call gradlew.bat --stop
if exist .gradle rmdir /s /q .gradle
if exist build rmdir /s /q build
if exist app\build rmdir /s /q app\build
call gradlew.bat clean assembleDebug
if errorlevel 1 (
  echo BUILD FAILED
  exit /b 1
)
echo.
echo APK: app\build\outputs\apk\debug\app-debug.apk
