package com.vvynas.soilwise;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatDelegate;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.vvynas.soilwise.util.AiClient;
import com.vvynas.soilwise.util.AiProvider;
import com.vvynas.soilwise.util.Prefs;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SettingsActivity extends BaseActivity {

    private RadioGroup rgTheme, rgMode;
    private EditText etKey, etFeed, etModel, etBase;
    private Spinner spProvider;
    private Button btnModels;

    private AiProvider current;
    /** Unsaved per-provider edits: id -> {key, model, base} (raw field text). */
    private final Map<String, String[]> draft = new HashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        initToolbar(R.string.title_settings, true);

        rgTheme = findViewById(R.id.rgTheme);
        rgMode = findViewById(R.id.rgMode);
        etKey = findViewById(R.id.etKey);
        etFeed = findViewById(R.id.etFeed);
        etModel = findViewById(R.id.etModel);
        etBase = findViewById(R.id.etBase);
        spProvider = findViewById(R.id.spProvider);
        btnModels = findViewById(R.id.btnModels);

        switch (Prefs.theme(this)) {
            case "green": rgTheme.check(R.id.rbGreen); break;
            case "earth": rgTheme.check(R.id.rbEarth); break;
            default: rgTheme.check(R.id.rbBlue);
        }
        switch (Prefs.mode(this)) {
            case "light": rgMode.check(R.id.rbLight); break;
            case "dark": rgMode.check(R.id.rbDark); break;
            default: rgMode.check(R.id.rbSystem);
        }
        etFeed.setText(Prefs.feedUrl(this));

        String[] labels = new String[AiProvider.ALL.length];
        for (int i = 0; i < labels.length; i++) labels[i] = AiProvider.ALL[i].label;
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, labels);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spProvider.setAdapter(ad);

        current = AiProvider.byId(Prefs.provider(this));
        loadFields(current);
        spProvider.setSelection(AiProvider.indexOf(current.id));
        spProvider.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                AiProvider next = AiProvider.ALL[pos];
                if (next == current) return;
                draft.put(current.id, rawFields());
                current = next;
                loadFields(current);
            }
            @Override public void onNothingSelected(AdapterView<?> parent) { }
        });

        btnModels.setOnClickListener(v -> browseModels());
        findViewById(R.id.btnSave).setOnClickListener(v -> save());
    }

    private void loadFields(AiProvider p) {
        String[] d = draft.get(p.id);
        if (d == null) d = new String[]{Prefs.apiKey(this, p.id), Prefs.model(this, p.id), Prefs.baseUrl(this, p.id)};
        etKey.setText(d[0]);
        etModel.setText(d[1].isEmpty() ? AiClient.defaultModel(p) : d[1]);
        etBase.setText(d[2].isEmpty() ? p.baseUrl : d[2]);
    }

    private String[] rawFields() {
        return new String[]{etKey.getText().toString().trim(),
                etModel.getText().toString().trim(),
                etBase.getText().toString().trim()};
    }

    private void browseModels() {
        final AiProvider p = current;
        String[] f = rawFields();
        String key = f[0];
        if (key.isEmpty() && p.protocol == AiProvider.GEMINI) key = com.vvynas.soilwise.BuildConfig.GEMINI_API_KEY.trim();
        if (p.needsKey && key.isEmpty()) {
            toast(R.string.error_no_key);
            showModels(p.suggested);
            return;
        }
        final String k = key, base = f[2];
        btnModels.setEnabled(false);
        this.<List<String>>bg(() -> AiClient.listModels(p, base, k),
                list -> {
                    btnModels.setEnabled(true);
                    showModels(list.isEmpty() ? p.suggested : list.toArray(new String[0]));
                },
                msg -> {
                    btnModels.setEnabled(true);
                    toast(getString(R.string.models_failed, msg));
                    showModels(p.suggested);
                });
    }

    private void showModels(final String[] items) {
        if (items == null || items.length == 0) return;
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.models_pick)
                .setItems(items, (d, i) -> etModel.setText(items[i]))
                .setNegativeButton(R.string.close, null)
                .show();
    }

    private void save() {
        int t = rgTheme.getCheckedRadioButtonId();
        Prefs.setTheme(this, t == R.id.rbGreen ? "green" : t == R.id.rbEarth ? "earth" : "blue");

        int m = rgMode.getCheckedRadioButtonId();
        Prefs.setMode(this, m == R.id.rbLight ? "light" : m == R.id.rbDark ? "dark" : "system");

        draft.put(current.id, rawFields());
        for (AiProvider p : AiProvider.ALL) {
            String[] d = draft.get(p.id);
            if (d == null) continue;
            String model = d[1].equals(AiClient.defaultModel(p)) ? "" : d[1];
            String base = d[2].equals(p.baseUrl) ? "" : d[2];
            while (base.endsWith("/")) base = base.substring(0, base.length() - 1);
            Prefs.setApiKey(this, p.id, d[0]);
            Prefs.setModel(this, p.id, model);
            Prefs.setBaseUrl(this, p.id, base);
        }
        Prefs.setProvider(this, current.id);

        String feed = etFeed.getText().toString().trim();
        Prefs.setFeedUrl(this, feed.equals(Prefs.DEFAULT_FEED) ? "" : feed);

        toast(R.string.saved);
        AppCompatDelegate.setDefaultNightMode(Prefs.nightMode(this));
        recreate();   // re-applies the chosen theme to this screen
    }
}
