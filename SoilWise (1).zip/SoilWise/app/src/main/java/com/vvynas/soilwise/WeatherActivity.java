package com.vvynas.soilwise;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;
import androidx.core.location.LocationManagerCompat;

import com.vvynas.soilwise.util.GeminiClient;
import com.vvynas.soilwise.util.Net;
import com.vvynas.soilwise.util.Prefs;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class WeatherActivity extends BaseActivity {

    private static final String SYSTEM =
            "You are SoilWise, a practical agronomy assistant. Reply in plain text only (no markdown symbols). "
                    + "Be concise and give clear plant-now / wait / protect guidance with reasons.";

    private EditText etLat, etLon;
    private TextView tvForecast, tvAdvice;
    private View progress;
    private String forecastText = "";

    private final ActivityResultLauncher<String[]> permLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), r -> {
                if (hasLocationPermission()) fetchGps(); else toast(R.string.loc_denied);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
        initToolbar(R.string.title_weather, true);

        etLat = findViewById(R.id.etLat);
        etLon = findViewById(R.id.etLon);
        tvForecast = findViewById(R.id.tvForecast);
        tvAdvice = findViewById(R.id.tvAdvice);
        progress = findViewById(R.id.progress);
        etLat.setText(Prefs.lat(this));
        etLon.setText(Prefs.lon(this));

        findViewById(R.id.btnGps).setOnClickListener(v -> {
            if (hasLocationPermission()) fetchGps();
            else permLauncher.launch(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION});
        });
        findViewById(R.id.btnForecast).setOnClickListener(v -> getForecast());
        findViewById(R.id.btnAdvice).setOnClickListener(v -> getAdvice());
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void setBusy(boolean b) { progress.setVisibility(b ? View.VISIBLE : View.GONE); }

    @SuppressLint("MissingPermission")
    private void fetchGps() {
        LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        String provider = null;
        if (lm != null) {
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) provider = LocationManager.NETWORK_PROVIDER;
            else if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) provider = LocationManager.GPS_PROVIDER;
        }
        if (provider == null) {
            toast(R.string.loc_unavailable);
            return;
        }
        setBusy(true);
        try {
            LocationManagerCompat.getCurrentLocation(lm, provider, (android.os.CancellationSignal) null,
                    ContextCompat.getMainExecutor(this), loc -> {
                        if (!alive()) return;
                        setBusy(false);
                        if (loc == null) {
                            toast(R.string.loc_unavailable);
                            return;
                        }
                        etLat.setText(String.format(Locale.US, "%.4f", loc.getLatitude()));
                        etLon.setText(String.format(Locale.US, "%.4f", loc.getLongitude()));
                        getForecast();
                    });
        } catch (SecurityException e) {
            setBusy(false);
            toast(R.string.loc_denied);
        }
    }

    private void getForecast() {
        double lat, lon;
        try {
            lat = Double.parseDouble(etLat.getText().toString().trim());
            lon = Double.parseDouble(etLon.getText().toString().trim());
        } catch (NumberFormatException e) {
            toast(R.string.bad_coords);
            return;
        }
        if (lat < -90 || lat > 90 || lon < -180 || lon > 180) {
            toast(R.string.bad_coords);
            return;
        }
        Prefs.setLocation(this, String.format(Locale.US, "%.4f", lat), String.format(Locale.US, "%.4f", lon));
        final String url = String.format(Locale.US,
                "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
                        + "&current=temperature_2m,relative_humidity_2m"
                        + "&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max"
                        + "&timezone=auto&forecast_days=7", lat, lon);
        setBusy(true);
        this.<String>bg(() -> parseForecast(Net.request("GET", url, null, null)),
                text -> {
                    setBusy(false);
                    forecastText = text;
                    tvForecast.setText(text);
                },
                msg -> {
                    setBusy(false);
                    tvForecast.setText(getString(R.string.error_generic, msg));
                });
    }

    private static String parseForecast(String json) throws Exception {
        JSONObject j = new JSONObject(json);
        StringBuilder sb = new StringBuilder();
        JSONObject cur = j.optJSONObject("current");
        if (cur != null) {
            sb.append(String.format(Locale.US, "Now: %.1f°C, humidity %d%%\n\n",
                    cur.optDouble("temperature_2m"), cur.optInt("relative_humidity_2m")));
        }
        JSONObject d = j.getJSONObject("daily");
        JSONArray time = d.getJSONArray("time");
        JSONArray tmax = d.getJSONArray("temperature_2m_max");
        JSONArray tmin = d.getJSONArray("temperature_2m_min");
        JSONArray rain = d.getJSONArray("precipitation_sum");
        JSONArray prob = d.optJSONArray("precipitation_probability_max");
        for (int i = 0; i < time.length(); i++) {
            sb.append(String.format(Locale.US, "%s: %.0f to %.0f°C, rain %.1f mm (%d%%)\n",
                    time.getString(i), tmin.optDouble(i), tmax.optDouble(i), rain.optDouble(i),
                    prob == null ? 0 : prob.optInt(i)));
        }
        return sb.toString().trim();
    }

    private void getAdvice() {
        if (forecastText.isEmpty()) {
            toast(R.string.get_forecast_first);
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Today is ").append(new SimpleDateFormat("d MMMM yyyy", Locale.US).format(new Date()))
                .append(". Location (lat, lon): ").append(Prefs.lat(this)).append(", ").append(Prefs.lon(this))
                .append(".\n7-day forecast:\n").append(forecastText).append("\n");
        String soil = Prefs.lastSoilSummary(this);
        if (!soil.isEmpty()) sb.append("\nLatest soil report from this farmer:\n").append(soil).append("\n");
        sb.append("\nGive: 1) best crops to plant now for this location and season, 2) the best planting window in the next 7 days, ")
                .append("3) frost, heat, rain or disease risks, 4) irrigation guidance, 5) what to do this week.");
        final String prompt = sb.toString();
        setBusy(true);
        tvAdvice.setText("");
        this.<String>bg(() -> GeminiClient.generate(getApplicationContext(),
                        new JSONArray().put(GeminiClient.userText(prompt)), SYSTEM),
                text -> {
                    setBusy(false);
                    tvAdvice.setText(text);
                    Prefs.addHistory(this, "planting", "Planting advice", text);
                },
                msg -> {
                    setBusy(false);
                    tvAdvice.setText(getString(R.string.error_generic, msg));
                });
    }
}
