package com.vvynas.soilwise.util;

/**
 * Describes one AI backend. Only three wire protocols exist; many services
 * speak the OpenAI-compatible one, so a single entry covers lots of vendors.
 * Model names are always free text, so any current or future model/version works.
 */
public final class AiProvider {
    public static final int GEMINI = 0;      // Google generateContent
    public static final int OPENAI = 1;      // /chat/completions (OpenAI-compatible)
    public static final int ANTHROPIC = 2;   // /v1/messages

    public final String id;
    public final String label;
    public final int protocol;
    public final String baseUrl;
    public final String defaultModel;
    public final boolean needsKey;
    public final String[] suggested;

    private AiProvider(String id, String label, int protocol, String baseUrl,
                       String defaultModel, boolean needsKey, String... suggested) {
        this.id = id;
        this.label = label;
        this.protocol = protocol;
        this.baseUrl = baseUrl;
        this.defaultModel = defaultModel;
        this.needsKey = needsKey;
        this.suggested = suggested;
    }

    public static final AiProvider[] ALL = {
            new AiProvider("gemini", "Google Gemini", GEMINI,
                    "https://generativelanguage.googleapis.com/v1beta", "gemini-2.5-flash", true,
                    "gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro", "gemini-2.0-flash"),
            new AiProvider("openai", "OpenAI (ChatGPT)", OPENAI,
                    "https://api.openai.com/v1", "gpt-4o-mini", true,
                    "gpt-4o", "gpt-4o-mini", "gpt-4.1", "gpt-4.1-mini"),
            new AiProvider("anthropic", "Anthropic (Claude)", ANTHROPIC,
                    "https://api.anthropic.com", "claude-sonnet-5-5", true,
                    "claude-opus-5-5", "claude-sonnet-5-5", "claude-haiku-5-5"),
            new AiProvider("groq", "Groq", OPENAI,
                    "https://api.groq.com/openai/v1", "meta-llama/llama-4-scout-17b-16e-instruct", true,
                    "meta-llama/llama-4-scout-17b-16e-instruct", "llama-3.3-70b-versatile"),
            new AiProvider("openrouter", "OpenRouter (any model)", OPENAI,
                    "https://openrouter.ai/api/v1", "google/gemini-2.5-flash", true,
                    "google/gemini-2.5-flash", "openai/gpt-4o-mini"),
            new AiProvider("mistral", "Mistral", OPENAI,
                    "https://api.mistral.ai/v1", "mistral-small-latest", true,
                    "mistral-small-latest", "mistral-large-latest", "pixtral-large-latest"),
            new AiProvider("deepseek", "DeepSeek", OPENAI,
                    "https://api.deepseek.com/v1", "deepseek-chat", true,
                    "deepseek-chat", "deepseek-reasoner"),
            new AiProvider("xai", "xAI (Grok)", OPENAI,
                    "https://api.x.ai/v1", "grok-4", true,
                    "grok-4"),
            new AiProvider("custom", "Custom (OpenAI-compatible URL)", OPENAI,
                    "", "", false)
    };

    public static AiProvider byId(String id) {
        for (AiProvider p : ALL) if (p.id.equals(id)) return p;
        return ALL[0];
    }

    public static int indexOf(String id) {
        for (int i = 0; i < ALL.length; i++) if (ALL[i].id.equals(id)) return i;
        return 0;
    }
}
