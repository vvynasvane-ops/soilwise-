package com.vvynas.soilwise.util;

import android.content.Context;
import android.util.Base64;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Conversation builders (Gemini-style JSON, used as the app's neutral format)
 * plus thin delegates to {@link AiClient}, which talks to whichever provider
 * and model is selected in Settings. Name kept so existing screens are unchanged.
 */
public final class GeminiClient {
    private GeminiClient() {}

    public static String apiKey(Context c) { return AiClient.apiKey(c); }

    public static JSONObject userText(String text) throws JSONException {
        return new JSONObject().put("role", "user")
                .put("parts", new JSONArray().put(new JSONObject().put("text", text)));
    }

    public static JSONObject modelText(String text) throws JSONException {
        return new JSONObject().put("role", "model")
                .put("parts", new JSONArray().put(new JSONObject().put("text", text)));
    }

    public static JSONObject userImage(String text, byte[] jpeg) throws JSONException {
        JSONObject inline = new JSONObject()
                .put("mime_type", "image/jpeg")
                .put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP));
        return new JSONObject().put("role", "user").put("parts", new JSONArray()
                .put(new JSONObject().put("text", text))
                .put(new JSONObject().put("inline_data", inline)));
    }

    /** Blocking call. Throws Exception with a user-friendly message. */
    public static String generate(Context c, JSONArray contents, String system) throws Exception {
        return AiClient.generate(c, contents, system);
    }
}
