package com.vvynas.soilwise;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.vvynas.soilwise.util.AiClient;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initToolbar(R.string.app_name, false);

        open(R.id.btnAnalyze, AnalyzeActivity.class);
        open(R.id.btnWeather, WeatherActivity.class);
        open(R.id.btnAdvisor, AdvisorActivity.class);
        open(R.id.btnNews, NewsActivity.class);
        open(R.id.btnHistory, HistoryActivity.class);
        open(R.id.btnSettings, SettingsActivity.class);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean missing = !AiClient.isConfigured(this);
        findViewById(R.id.tvKeyWarning).setVisibility(missing ? View.VISIBLE : View.GONE);
    }

    private void open(int buttonId, Class<?> target) {
        findViewById(buttonId).setOnClickListener(v -> startActivity(new Intent(this, target)));
    }
}
