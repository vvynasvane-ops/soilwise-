package com.vvynas.soilwise.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public final class ImageUtil {
    private ImageUtil() {}

    private static InputStream open(Context c, Uri uri) throws IOException {
        InputStream in = c.getContentResolver().openInputStream(uri);
        if (in == null) throw new IOException("Cannot open image");
        return in;
    }

    /** Decode a down-scaled bitmap whose longest side is at most maxDim. */
    public static Bitmap loadBitmap(Context c, Uri uri, int maxDim) throws IOException {
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = open(c, uri)) {
            BitmapFactory.decodeStream(in, null, bounds);
        }
        int sample = 1;
        while (Math.max(bounds.outWidth, bounds.outHeight) / sample > maxDim * 2) sample *= 2;

        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        Bitmap bmp;
        try (InputStream in = open(c, uri)) {
            bmp = BitmapFactory.decodeStream(in, null, opts);
        }
        if (bmp == null) throw new IOException("Cannot decode image");

        float scale = Math.min(1f, (float) maxDim / Math.max(bmp.getWidth(), bmp.getHeight()));
        if (scale < 1f) {
            Bitmap scaled = Bitmap.createScaledBitmap(bmp,
                    Math.max(1, Math.round(bmp.getWidth() * scale)),
                    Math.max(1, Math.round(bmp.getHeight() * scale)), true);
            if (scaled != bmp) bmp.recycle();
            bmp = scaled;
        }
        return bmp;
    }

    public static byte[] loadJpeg(Context c, Uri uri, int maxDim) throws IOException {
        Bitmap bmp = loadBitmap(c, uri, maxDim);
        try (ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            bmp.compress(Bitmap.CompressFormat.JPEG, 85, out);
            return out.toByteArray();
        } finally {
            bmp.recycle();
        }
    }
}
