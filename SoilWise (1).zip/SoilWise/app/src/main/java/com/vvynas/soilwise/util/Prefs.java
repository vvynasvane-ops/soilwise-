package com.vvynas.soilwise.util;

import android.content.Context;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class Prefs {
    public static final String DEFAULT_FEED =
            "https://www.sciencedaily.com/rss/plants_animals/agriculture_and_food.xml";
    private static final String FILE = "soilwise_prefs";

    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static String theme(Context c) { return sp(c).getString("theme", "blue"); }
    public static void setTheme(Context c, String v) { sp(c).edit().putString("theme", v).apply(); }

    public static String mode(Context c) { return sp(c).getString("mode", "system"); }
    public static void setMode(Context c, String v) { sp(c).edit().putString("mode", v).apply(); }

    public static int nightMode(Context c) {
        switch (mode(c)) {
            case "light": return AppCompatDelegate.MODE_NIGHT_NO;
            case "dark": return AppCompatDelegate.MODE_NIGHT_YES;
            default: return AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM;
        }
    }

    // ---- AI provider / model / key (per provider) ----
    public static String provider(Context c) { return sp(c).getString("ai_provider", "gemini"); }
    public static void setProvider(Context c, String v) { sp(c).edit().putString("ai_provider", v).apply(); }

    public static String apiKey(Context c, String provider) {
        String k = sp(c).getString("key_" + provider, "");
        if (k.isEmpty() && "gemini".equals(provider)) k = sp(c).getString("api_key", "");   // pre-multi-provider key
        return k;
    }
    public static void setApiKey(Context c, String provider, String v) {
        SharedPreferences.Editor e = sp(c).edit().putString("key_" + provider, v);
        if ("gemini".equals(provider)) e.remove("api_key");
        e.apply();
    }

    public static String model(Context c, String provider) { return sp(c).getString("model_" + provider, ""); }
    public static void setModel(Context c, String provider, String v) { sp(c).edit().putString("model_" + provider, v).apply(); }

    public static String baseUrl(Context c, String provider) { return sp(c).getString("base_" + provider, ""); }
    public static void setBaseUrl(Context c, String provider, String v) { sp(c).edit().putString("base_" + provider, v).apply(); }

    public static String feedUrl(Context c) {
        String v = sp(c).getString("feed", "");
        return v.isEmpty() ? DEFAULT_FEED : v;
    }
    public static void setFeedUrl(Context c, String v) { sp(c).edit().putString("feed", v).apply(); }

    public static String lat(Context c) { return sp(c).getString("lat", ""); }
    public static String lon(Context c) { return sp(c).getString("lon", ""); }
    public static void setLocation(Context c, String lat, String lon) {
        sp(c).edit().putString("lat", lat).putString("lon", lon).apply();
    }

    // ---- history (max 50 entries, newest first) ----
    public static void addHistory(Context c, String type, String title, String body) {
        try {
            JSONArray old = new JSONArray(sp(c).getString("history", "[]"));
            JSONArray out = new JSONArray();
            out.put(new JSONObject().put("t", System.currentTimeMillis())
                    .put("type", type).put("title", title).put("body", body));
            for (int i = 0; i < old.length() && i < 49; i++) out.put(old.get(i));
            sp(c).edit().putString("history", out.toString()).apply();
        } catch (JSONException ignored) { }
    }

    public static JSONArray history(Context c) {
        try {
            return new JSONArray(sp(c).getString("history", "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    public static void clearHistory(Context c) { sp(c).edit().remove("history").apply(); }

    /** Most recent soil report text (trimmed) or "" if none. */
    public static String lastSoilSummary(Context c) {
        JSONArray h = history(c);
        for (int i = 0; i < h.length(); i++) {
            JSONObject o = h.optJSONObject(i);
            if (o != null && "soil".equals(o.optString("type"))) {
                String b = o.optString("body");
                return b.length() > 1200 ? b.substring(0, 1200) : b;
            }
        }
        return "";
    }
}
