package com.vvynas.soilwise;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.FileProvider;

import com.vvynas.soilwise.util.GeminiClient;
import com.vvynas.soilwise.util.ImageUtil;
import com.vvynas.soilwise.util.Prefs;

import org.json.JSONArray;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AnalyzeActivity extends BaseActivity {

    private static final String SYSTEM =
            "You are SoilWise, a practical agronomy assistant for farmers. Reply in plain text only "
                    + "(no markdown symbols like * or #). Use short numbered sections and simple language. "
                    + "Always state confidence (low/medium/high) and that photo analysis is an estimate.";

    private ImageView img;
    private TextView tvResult;
    private EditText etNote;
    private View progress;
    private Button btnAnalyze;
    private Uri photoUri;

    private final ActivityResultLauncher<Uri> takePicture =
            registerForActivityResult(new ActivityResultContracts.TakePicture(), ok -> {
                if (Boolean.TRUE.equals(ok) && photoUri != null) showPhoto(photoUri);
            });

    private final ActivityResultLauncher<String> pickImage =
            registerForActivityResult(new ActivityResultContracts.GetContent(), uri -> {
                if (uri != null) showPhoto(uri);
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analyze);
        initToolbar(R.string.title_analyze, true);

        img = findViewById(R.id.img);
        tvResult = findViewById(R.id.tvResult);
        etNote = findViewById(R.id.etNote);
        progress = findViewById(R.id.progress);
        btnAnalyze = findViewById(R.id.btnAnalyze);

        findViewById(R.id.btnCamera).setOnClickListener(v -> launchCamera());
        findViewById(R.id.btnGallery).setOnClickListener(v -> pickImage.launch("image/*"));
        btnAnalyze.setOnClickListener(v -> analyze());
    }

    private void launchCamera() {
        try {
            File dir = new File(getCacheDir(), "images");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("Cannot create cache dir");
            File f = File.createTempFile("soil_", ".jpg", dir);
            photoUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", f);
            takePicture.launch(photoUri);
        } catch (Exception e) {
            toast(R.string.camera_failed);
        }
    }

    private void showPhoto(final Uri uri) {
        photoUri = uri;
        this.<Bitmap>bg(() -> ImageUtil.loadBitmap(getApplicationContext(), uri, 800),
                bmp -> img.setImageBitmap(bmp),
                msg -> toast(R.string.photo_failed));
    }

    private void setBusy(boolean busy) {
        progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        btnAnalyze.setEnabled(!busy);
    }

    private String buildPrompt(String note) {
        StringBuilder sb = new StringBuilder();
        sb.append("Analyze this soil photo for a farmer. Date: ")
                .append(new SimpleDateFormat("d MMMM yyyy", Locale.US).format(new Date())).append(". ");
        String lat = Prefs.lat(this), lon = Prefs.lon(this);
        if (!lat.isEmpty() && !lon.isEmpty()) sb.append("Location (lat, lon): ").append(lat).append(", ").append(lon).append(". ");
        if (!note.isEmpty()) sb.append("Farmer notes: ").append(note).append(". ");
        sb.append("If the image is not soil, say so and stop. Otherwise give these sections: ")
                .append("1) Observations: texture guess (sandy/loamy/clayey/silty), color, moisture, organic matter cues, structure, compaction, crusting, salinity or erosion signs. ")
                .append("2) Improvement steps: practical, low-cost first (organic matter, cover crops, tillage, drainage, pH guidance). ")
                .append("3) Best crops to plant now for this soil and season. ")
                .append("4) Weeds and pests likely in this soil, with prevention and early action. ")
                .append("5) Cautions and what a lab test should confirm.");
        return sb.toString();
    }

    private void analyze() {
        if (photoUri == null) {
            toast(R.string.no_photo);
            return;
        }
        final Uri uri = photoUri;
        final String note = etNote.getText().toString().trim();
        final String prompt = buildPrompt(note);
        setBusy(true);
        tvResult.setText("");
        this.<String>bg(() -> {
                    byte[] jpeg = ImageUtil.loadJpeg(getApplicationContext(), uri, 1024);
                    JSONArray contents = new JSONArray().put(GeminiClient.userImage(prompt, jpeg));
                    return GeminiClient.generate(getApplicationContext(), contents, SYSTEM);
                },
                text -> {
                    setBusy(false);
                    tvResult.setText(text);
                    Prefs.addHistory(this, "soil", note.isEmpty() ? "Soil analysis" : "Soil analysis - " + note, text);
                },
                msg -> {
                    setBusy(false);
                    tvResult.setText(getString(R.string.error_generic, msg));
                });
    }
}
