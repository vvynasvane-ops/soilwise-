package com.vvynas.soilwise.util;

import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Tiny background-thread + HTTP helper (no third-party libraries). */
public final class Net {
    private static final ExecutorService EXEC = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    public interface Task<T> { T run() throws Exception; }
    public interface Ok<T> { void run(T value); }
    public interface Err { void run(String message); }

    public static class HttpException extends Exception {
        public final int code;
        public final String body;
        public HttpException(int code, String body) {
            super("HTTP " + code);
            this.code = code;
            this.body = body;
        }
    }

    private Net() {}

    public static <T> void async(final Task<T> task, final Ok<T> ok, final Err err) {
        EXEC.execute(() -> {
            try {
                final T value = task.run();
                MAIN.post(() -> ok.run(value));
            } catch (final Exception e) {
                final String msg = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
                MAIN.post(() -> err.run(msg));
            }
        });
    }

    public static String request(String method, String url, String body, String[][] headers)
            throws IOException, HttpException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(15000);
            c.setReadTimeout(60000);
            c.setRequestMethod(method);
            c.setRequestProperty("User-Agent", "SoilWise/1.0 (Android)");
            if (headers != null) {
                for (String[] h : headers) c.setRequestProperty(h[0], h[1]);
            }
            if (body != null) {
                c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                try (OutputStream os = c.getOutputStream()) {
                    os.write(body.getBytes(StandardCharsets.UTF_8));
                }
            }
            int code = c.getResponseCode();
            InputStream is = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String text = is == null ? "" : readAll(is);
            if (code >= 400) throw new HttpException(code, text);
            return text;
        } finally {
            c.disconnect();
        }
    }

    private static String readAll(InputStream is) throws IOException {
        try (InputStream in = is; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        }
    }
}
