package com.vvynas.soilwise;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;

import com.vvynas.soilwise.util.GeminiClient;
import com.vvynas.soilwise.util.Prefs;

import org.json.JSONArray;
import org.json.JSONException;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AdvisorActivity extends BaseActivity {

    private final JSONArray conversation = new JSONArray();
    private TextView tvChat;
    private ScrollView scroll;
    private EditText etMsg;
    private Button btnSend;
    private View progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advisor);
        initToolbar(R.string.title_advisor, true);

        tvChat = findViewById(R.id.tvChat);
        scroll = findViewById(R.id.scroll);
        etMsg = findViewById(R.id.etMsg);
        btnSend = findViewById(R.id.btnSend);
        progress = findViewById(R.id.progress);
        btnSend.setOnClickListener(v -> send());
    }

    private String system() {
        StringBuilder sb = new StringBuilder(
                "You are SoilWise Advisor, a practical agronomy assistant for farmers. Reply in plain text only "
                        + "(no markdown symbols), simple language, short steps. Prefer low-cost, low-chemical options first. "
                        + "Say when you are unsure and recommend a local extension officer or a lab test for critical decisions. "
                        + "Follow product labels and local regulations for any pesticide. Today is ")
                .append(new SimpleDateFormat("d MMMM yyyy", Locale.US).format(new Date())).append(".");
        String lat = Prefs.lat(this), lon = Prefs.lon(this);
        if (!lat.isEmpty() && !lon.isEmpty()) sb.append(" Farmer location (lat, lon): ").append(lat).append(", ").append(lon).append(".");
        return sb.toString();
    }

    private void append(String who, String text) {
        tvChat.append(who + ": " + text + "\n\n");
        scroll.post(() -> scroll.fullScroll(View.FOCUS_DOWN));
    }

    private void setBusy(boolean b) {
        progress.setVisibility(b ? View.VISIBLE : View.GONE);
        btnSend.setEnabled(!b);
    }

    private void send() {
        final String msg = etMsg.getText().toString().trim();
        if (msg.isEmpty()) return;
        final JSONArray snapshot;
        try {
            conversation.put(GeminiClient.userText(msg));
            while (conversation.length() > 20) {   // keep context small; drop oldest pair
                conversation.remove(0);
                conversation.remove(0);
            }
            snapshot = new JSONArray(conversation.toString());
        } catch (JSONException e) {
            toast(getString(R.string.error_generic, e.getMessage()));
            return;
        }
        etMsg.setText("");
        append(getString(R.string.you), msg);
        setBusy(true);
        final String system = system();
        this.<String>bg(() -> GeminiClient.generate(getApplicationContext(), snapshot, system),
                reply -> {
                    setBusy(false);
                    try {
                        conversation.put(GeminiClient.modelText(reply));
                    } catch (JSONException ignored) { }
                    append(getString(R.string.advisor), reply);
                },
                err -> {
                    setBusy(false);
                    conversation.remove(conversation.length() - 1);  // drop unanswered question
                    append(getString(R.string.advisor), getString(R.string.error_generic, err));
                });
    }
}
