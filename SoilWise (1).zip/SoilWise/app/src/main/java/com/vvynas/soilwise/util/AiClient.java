package com.vvynas.soilwise.util;

import android.content.Context;

import com.vvynas.soilwise.BuildConfig;
import com.vvynas.soilwise.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Provider-agnostic AI client (Gemini, OpenAI-compatible, Anthropic).
 * Conversations are passed in Gemini-style JSON (see GeminiClient helpers) and
 * converted to each provider's wire format here. Blocking: call from bg().
 */
public final class AiClient {
    private static final String ANTHROPIC_VERSION = "2023-06-01";
    private static final int ANTHROPIC_MAX_TOKENS = 4096;

    private AiClient() {}

    // ---------- effective settings ----------

    public static AiProvider provider(Context c) { return AiProvider.byId(Prefs.provider(c)); }

    public static String defaultModel(AiProvider p) {
        if (p.protocol == AiProvider.GEMINI) {
            String m = BuildConfig.GEMINI_MODEL.trim();
            if (!m.isEmpty()) return m;
        }
        return p.defaultModel;
    }

    public static String apiKey(Context c) {
        AiProvider p = provider(c);
        String k = Prefs.apiKey(c, p.id).trim();
        if (k.isEmpty() && p.protocol == AiProvider.GEMINI) k = BuildConfig.GEMINI_API_KEY.trim();
        return k;
    }

    public static String model(Context c) {
        AiProvider p = provider(c);
        String m = Prefs.model(c, p.id).trim();
        return m.isEmpty() ? defaultModel(p) : m;
    }

    public static String baseUrl(Context c) {
        AiProvider p = provider(c);
        String b = Prefs.baseUrl(c, p.id).trim();
        return stripSlash(b.isEmpty() ? p.baseUrl : b);
    }

    public static boolean isConfigured(Context c) {
        AiProvider p = provider(c);
        return (!p.needsKey || !apiKey(c).isEmpty()) && !model(c).isEmpty() && !baseUrl(c).isEmpty();
    }

    private static String stripSlash(String s) {
        s = s.trim();
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    // ---------- generate ----------

    public static String generate(Context c, JSONArray contents, String system) throws Exception {
        AiProvider p = provider(c);
        String key = apiKey(c);
        if (p.needsKey && key.isEmpty()) throw new Exception(c.getString(R.string.error_no_key));
        String model = model(c);
        if (model.isEmpty()) throw new Exception(c.getString(R.string.error_no_model));
        String base = baseUrl(c);
        if (base.isEmpty()) throw new Exception(c.getString(R.string.error_no_base));

        try {
            switch (p.protocol) {
                case AiProvider.ANTHROPIC: {
                    JSONObject body = new JSONObject()
                            .put("model", model)
                            .put("max_tokens", ANTHROPIC_MAX_TOKENS)
                            .put("messages", toAnthropic(contents));
                    if (system != null && !system.isEmpty()) body.put("system", system);
                    String resp = Net.request("POST", base + "/v1/messages", body.toString(), headers(p, key));
                    return extractAnthropic(resp);
                }
                case AiProvider.OPENAI: {
                    JSONObject body = new JSONObject()
                            .put("model", model)
                            .put("messages", toOpenAi(contents, system));
                    String resp = Net.request("POST", base + "/chat/completions", body.toString(), headers(p, key));
                    return extractOpenAi(resp);
                }
                default: {
                    JSONObject body = new JSONObject().put("contents", contents);
                    if (system != null && !system.isEmpty()) {
                        body.put("systemInstruction", new JSONObject().put("parts",
                                new JSONArray().put(new JSONObject().put("text", system))));
                    }
                    String path = model.startsWith("tunedModels/") ? "/" + model
                            : "/models/" + (model.startsWith("models/") ? model.substring(7) : model);
                    String resp = Net.request("POST", base + path + ":generateContent", body.toString(), headers(p, key));
                    return extractGemini(resp);
                }
            }
        } catch (Net.HttpException e) {
            throw new Exception(friendly(e, model));
        } catch (IOException e) {
            throw new Exception(c.getString(R.string.error_network));
        }
    }

    // ---------- list models (for the Settings picker) ----------

    public static List<String> listModels(AiProvider p, String base, String key) throws Exception {
        base = stripSlash(base == null || base.trim().isEmpty() ? p.baseUrl : base);
        ArrayList<String> out = new ArrayList<>();
        try {
            switch (p.protocol) {
                case AiProvider.ANTHROPIC: {
                    String resp = Net.request("GET", base + "/v1/models?limit=1000", null, headers(p, key));
                    JSONArray a = new JSONObject(resp).optJSONArray("data");
                    for (int i = 0; a != null && i < a.length(); i++) out.add(a.getJSONObject(i).optString("id"));
                    break;
                }
                case AiProvider.OPENAI: {
                    String resp = Net.request("GET", base + "/models", null, headers(p, key));
                    JSONArray a = new JSONObject(resp).optJSONArray("data");
                    for (int i = 0; a != null && i < a.length(); i++) out.add(a.getJSONObject(i).optString("id"));
                    break;
                }
                default: {
                    String resp = Net.request("GET", base + "/models?pageSize=1000", null, headers(p, key));
                    JSONArray a = new JSONObject(resp).optJSONArray("models");
                    for (int i = 0; a != null && i < a.length(); i++) {
                        JSONObject o = a.getJSONObject(i);
                        JSONArray methods = o.optJSONArray("supportedGenerationMethods");
                        boolean ok = methods == null;
                        for (int j = 0; methods != null && j < methods.length(); j++) {
                            if ("generateContent".equals(methods.optString(j))) ok = true;
                        }
                        if (!ok) continue;
                        String name = o.optString("name");
                        out.add(name.startsWith("models/") ? name.substring(7) : name);
                    }
                }
            }
        } catch (Net.HttpException e) {
            throw new Exception(friendly(e, ""));
        } catch (IOException e) {
            throw new Exception("Network error. Check your connection and the base URL.");
        }
        out.removeAll(Collections.singleton(""));
        Collections.sort(out);
        return out;
    }

    // ---------- request helpers ----------

    private static String[][] headers(AiProvider p, String key) {
        key = key == null ? "" : key.trim();
        switch (p.protocol) {
            case AiProvider.ANTHROPIC:
                return new String[][]{{"x-api-key", key}, {"anthropic-version", ANTHROPIC_VERSION}};
            case AiProvider.OPENAI:
                return key.isEmpty() ? new String[0][] : new String[][]{{"Authorization", "Bearer " + key}};
            default:
                return new String[][]{{"x-goog-api-key", key}};
        }
    }

    /** Gemini-style contents -> OpenAI chat messages. */
    private static JSONArray toOpenAi(JSONArray contents, String system) throws JSONException {
        JSONArray out = new JSONArray();
        if (system != null && !system.isEmpty()) {
            out.put(new JSONObject().put("role", "system").put("content", system));
        }
        for (int i = 0; i < contents.length(); i++) {
            JSONObject m = contents.getJSONObject(i);
            String role = "model".equals(m.optString("role")) ? "assistant" : "user";
            JSONArray parts = m.getJSONArray("parts");
            boolean hasImage = false;
            for (int j = 0; j < parts.length(); j++) if (parts.getJSONObject(j).has("inline_data")) hasImage = true;
            if (!hasImage) {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < parts.length(); j++) sb.append(parts.getJSONObject(j).optString("text", ""));
                out.put(new JSONObject().put("role", role).put("content", sb.toString()));
            } else {
                JSONArray arr = new JSONArray();
                for (int j = 0; j < parts.length(); j++) {
                    JSONObject part = parts.getJSONObject(j);
                    JSONObject inline = part.optJSONObject("inline_data");
                    if (inline != null) {
                        String url = "data:" + inline.optString("mime_type", "image/jpeg")
                                + ";base64," + inline.optString("data");
                        arr.put(new JSONObject().put("type", "image_url")
                                .put("image_url", new JSONObject().put("url", url)));
                    } else {
                        arr.put(new JSONObject().put("type", "text").put("text", part.optString("text", "")));
                    }
                }
                out.put(new JSONObject().put("role", role).put("content", arr));
            }
        }
        return out;
    }

    /** Gemini-style contents -> Anthropic messages (same-role neighbours merged). */
    private static JSONArray toAnthropic(JSONArray contents) throws JSONException {
        JSONArray out = new JSONArray();
        String lastRole = null;
        JSONArray lastBlocks = null;
        for (int i = 0; i < contents.length(); i++) {
            JSONObject m = contents.getJSONObject(i);
            String role = "model".equals(m.optString("role")) ? "assistant" : "user";
            JSONArray parts = m.getJSONArray("parts");
            JSONArray blocks = new JSONArray();
            for (int j = 0; j < parts.length(); j++) {
                JSONObject part = parts.getJSONObject(j);
                JSONObject inline = part.optJSONObject("inline_data");
                if (inline != null) {
                    blocks.put(new JSONObject().put("type", "image").put("source", new JSONObject()
                            .put("type", "base64")
                            .put("media_type", inline.optString("mime_type", "image/jpeg"))
                            .put("data", inline.optString("data"))));
                } else {
                    String t = part.optString("text", "");
                    if (!t.trim().isEmpty()) blocks.put(new JSONObject().put("type", "text").put("text", t));
                }
            }
            if (blocks.length() == 0) continue;
            if (role.equals(lastRole) && lastBlocks != null) {
                for (int j = 0; j < blocks.length(); j++) lastBlocks.put(blocks.get(j));
            } else {
                out.put(new JSONObject().put("role", role).put("content", blocks));
                lastRole = role;
                lastBlocks = blocks;
            }
        }
        return out;
    }

    // ---------- response parsing ----------

    private static String extractGemini(String resp) throws Exception {
        JSONObject r = new JSONObject(resp);
        JSONArray cands = r.optJSONArray("candidates");
        if (cands == null || cands.length() == 0) {
            JSONObject fb = r.optJSONObject("promptFeedback");
            if (fb != null && fb.has("blockReason")) throw new Exception("Request was blocked by the AI safety filter.");
            throw new Exception("Empty response from the AI.");
        }
        JSONObject content = cands.getJSONObject(0).optJSONObject("content");
        JSONArray parts = content == null ? null : content.optJSONArray("parts");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; parts != null && i < parts.length(); i++) {
            JSONObject part = parts.getJSONObject(i);
            if (part.optBoolean("thought", false)) continue;   // skip reasoning summaries
            sb.append(part.optString("text", ""));
        }
        return nonEmpty(sb.toString());
    }

    private static String extractOpenAi(String resp) throws Exception {
        JSONObject r = new JSONObject(resp);
        JSONArray choices = r.optJSONArray("choices");
        if (choices == null || choices.length() == 0) throw new Exception("Empty response from the AI.");
        JSONObject msg = choices.getJSONObject(0).optJSONObject("message");
        StringBuilder sb = new StringBuilder();
        Object content = msg == null ? null : msg.opt("content");
        if (content instanceof String) {
            sb.append((String) content);
        } else if (content instanceof JSONArray) {
            JSONArray arr = (JSONArray) content;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject part = arr.optJSONObject(i);
                if (part != null) sb.append(part.optString("text", ""));
            }
        }
        if (sb.toString().trim().isEmpty() && msg != null && msg.optString("refusal", "").length() > 0) {
            throw new Exception("The AI declined this request.");
        }
        return nonEmpty(sb.toString());
    }

    private static String extractAnthropic(String resp) throws Exception {
        JSONObject r = new JSONObject(resp);
        JSONArray content = r.optJSONArray("content");
        StringBuilder sb = new StringBuilder();
        for (int i = 0; content != null && i < content.length(); i++) {
            JSONObject b = content.getJSONObject(i);
            if ("text".equals(b.optString("type"))) sb.append(b.optString("text", ""));
        }
        return nonEmpty(sb.toString());
    }

    private static String nonEmpty(String s) throws Exception {
        String t = s.trim();
        if (t.isEmpty()) throw new Exception("The AI returned no text. Try again.");
        return t;
    }

    private static String friendly(Net.HttpException e, String model) {
        String detail = "";
        try {
            JSONObject o = new JSONObject(e.body);
            Object err = o.opt("error");
            if (err instanceof JSONObject) detail = ((JSONObject) err).optString("message", "");
            else if (err instanceof String) detail = (String) err;
            else detail = o.optString("message", "");
        } catch (JSONException ignored) { }
        String low = detail.toLowerCase();
        if (e.code == 429) return "Rate limit or quota reached. Try again later.";
        if (e.code == 400 && (low.contains("api key") || low.contains("api_key"))) return "Invalid API key.";
        if (e.code == 401 || e.code == 403) return "API key rejected or not permitted (" + e.code + ")."
                + (detail.isEmpty() ? "" : " " + detail);
        if (e.code == 404) return "Model or endpoint not found" + (model.isEmpty() ? "" : " (" + model + ")")
                + ". Check the model name and base URL in Settings.";
        return detail.isEmpty() ? "AI error " + e.code : detail;
    }
}
