package com.vvynas.soilwise;

import android.app.Application;

import androidx.appcompat.app.AppCompatDelegate;

import com.vvynas.soilwise.util.Prefs;

public class SoilWiseApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        AppCompatDelegate.setDefaultNightMode(Prefs.nightMode(this));
    }
}
