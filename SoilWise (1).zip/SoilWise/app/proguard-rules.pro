# SoilWise has no reflection-based libraries; no extra rules needed.
