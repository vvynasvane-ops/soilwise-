@echo off
rem Re-download the Gradle wrapper jar if it is missing or corrupt
if not exist gradle\wrapper mkdir gradle\wrapper
curl -L -o gradle\wrapper\gradle-wrapper.jar https://github.com/gradle/gradle/raw/v8.10.2/gradle/wrapper/gradle-wrapper.jar
