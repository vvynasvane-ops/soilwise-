package com.vvynas.soilwise;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Html;
import android.util.Xml;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.vvynas.soilwise.util.GeminiClient;
import com.vvynas.soilwise.util.Net;
import com.vvynas.soilwise.util.Prefs;

import org.json.JSONArray;
import org.xmlpull.v1.XmlPullParser;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

public class NewsActivity extends BaseActivity {

    private final List<String[]> items = new ArrayList<>();   // {title, link, description}
    private final List<String> titles = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private View progress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        initToolbar(R.string.title_news, true);

        progress = findViewById(R.id.progress);
        ListView list = findViewById(R.id.list);
        adapter = new ArrayAdapter<>(this, R.layout.item_row, R.id.tvRowText, titles);
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> openLink(items.get(pos)[1]));

        findViewById(R.id.btnRefresh).setOnClickListener(v -> load());
        findViewById(R.id.btnSummarize).setOnClickListener(v -> summarize());
        load();
    }

    private void openLink(String link) {
        if (link == null || !(link.startsWith("https://") || link.startsWith("http://"))) {
            toast(R.string.open_failed);
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link)));
        } catch (Exception e) {
            toast(R.string.open_failed);
        }
    }

    private void load() {
        final String url = Prefs.feedUrl(this);
        progress.setVisibility(View.VISIBLE);
        this.<List<String[]>>bg(() -> parse(Net.request("GET", url, null, null)),
                result -> {
                    progress.setVisibility(View.GONE);
                    items.clear();
                    titles.clear();
                    items.addAll(result);
                    for (String[] it : result) titles.add(it[0]);
                    adapter.notifyDataSetChanged();
                    if (result.isEmpty()) toast(R.string.news_empty);
                },
                msg -> {
                    progress.setVisibility(View.GONE);
                    toast(getString(R.string.error_generic, msg));
                });
    }

    private static String clean(String s) {
        return Html.fromHtml(s, Html.FROM_HTML_MODE_LEGACY).toString().replaceAll("\\s+", " ").trim();
    }

    /** Parses RSS 2.0 (item) and Atom (entry) feeds. */
    private static List<String[]> parse(String xml) throws Exception {
        XmlPullParser p = Xml.newPullParser();
        p.setInput(new StringReader(xml));
        List<String[]> out = new ArrayList<>();
        String[] cur = null;
        String tag = null;
        int ev = p.getEventType();
        while (ev != XmlPullParser.END_DOCUMENT && out.size() < 30) {
            if (ev == XmlPullParser.START_TAG) {
                tag = p.getName();
                if ("item".equals(tag) || "entry".equals(tag)) {
                    cur = new String[]{"", "", ""};
                } else if (cur != null && "link".equals(tag)) {
                    String href = p.getAttributeValue(null, "href");
                    if (href != null) cur[1] = href;
                }
            } else if (ev == XmlPullParser.TEXT && cur != null && tag != null) {
                String t = p.getText();
                if ("title".equals(tag)) cur[0] += t;
                else if ("link".equals(tag)) cur[1] += t;
                else if ("description".equals(tag) || "summary".equals(tag)) cur[2] += t;
            } else if (ev == XmlPullParser.END_TAG) {
                String n = p.getName();
                if ("item".equals(n) || "entry".equals(n)) {
                    if (cur != null && !cur[0].trim().isEmpty()) {
                        out.add(new String[]{clean(cur[0]), cur[1].trim(), clean(cur[2])});
                    }
                    cur = null;
                }
                tag = null;
            }
            ev = p.next();
        }
        return out;
    }

    private void summarize() {
        if (items.isEmpty()) {
            toast(R.string.news_empty);
            return;
        }
        StringBuilder sb = new StringBuilder(
                "Here are recent agriculture headlines. For a smallholder farmer, say which 3 to 5 matter most, "
                        + "why, and one practical action for each. Plain text only, no markdown symbols.\n\n");
        for (int i = 0; i < Math.min(10, items.size()); i++) {
            String d = items.get(i)[2];
            sb.append("- ").append(items.get(i)[0]).append(": ")
                    .append(d.length() > 200 ? d.substring(0, 200) : d).append("\n");
        }
        final String prompt = sb.toString();
        progress.setVisibility(View.VISIBLE);
        this.<String>bg(() -> GeminiClient.generate(getApplicationContext(),
                        new JSONArray().put(GeminiClient.userText(prompt)), null),
                text -> {
                    progress.setVisibility(View.GONE);
                    new MaterialAlertDialogBuilder(this).setTitle(R.string.summary_title)
                            .setMessage(text).setPositiveButton(R.string.close, null).show();
                },
                msg -> {
                    progress.setVisibility(View.GONE);
                    toast(getString(R.string.error_generic, msg));
                });
    }
}
