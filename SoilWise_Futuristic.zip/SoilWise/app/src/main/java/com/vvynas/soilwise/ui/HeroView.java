package com.vvynas.soilwise.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.SweepGradient;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.view.animation.LinearInterpolator;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.vvynas.soilwise.R;

/**
 * Animated "field radar" hero: rotating sweep, orbiting data nodes and a
 * glowing crop sprouting from a layered soil pad. Pure Canvas, no assets.
 */
public class HeroView extends View {

    private static final float TWO_PI = (float) (Math.PI * 2);

    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sweepPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint node = new Paint(Paint.ANTI_ALIAS_FLAG);

    private final Path leafL = new Path();
    private final Path leafR = new Path();
    private final Path bud = new Path();
    private final Path stem = new Path();
    private final Matrix sweepMatrix = new Matrix();

    private int accent;
    private int accentDim;
    private int cyan;
    private float density;

    private float phase;          // 0..1, loops forever
    private float cx, cy, r;
    private SweepGradient sweepShader;
    private ValueAnimator animator;

    public HeroView(Context c) { this(c, null); }

    public HeroView(Context c, @Nullable AttributeSet a) {
        super(c, a);
        density = c.getResources().getDisplayMetrics().density;
        accent = themeColor(R.attr.swAccent, Color.parseColor("#39FF9C"));
        accentDim = themeColor(R.attr.swAccentDim, Color.parseColor("#4439FF9C"));
        cyan = ContextCompat.getColor(c, R.color.sw_cyan);

        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(1f * density);
        ring.setColor(accentDim);

        tick.setStyle(Paint.Style.STROKE);
        tick.setStrokeWidth(1.2f * density);
        tick.setColor(accentDim);

        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        line.setColor(accent);

        fill.setStyle(Paint.Style.FILL);
        node.setStyle(Paint.Style.FILL);
        setLayerType(LAYER_TYPE_HARDWARE, null);
    }

    private int themeColor(int attr, int fallback) {
        TypedValue tv = new TypedValue();
        if (getContext().getTheme().resolveAttribute(attr, tv, true)
                && tv.type >= TypedValue.TYPE_FIRST_COLOR_INT && tv.type <= TypedValue.TYPE_LAST_COLOR_INT) {
            return tv.data;
        }
        return fallback;
    }

    private static int alpha(int color, int a) {
        return (color & 0x00FFFFFF) | (Math.max(0, Math.min(255, a)) << 24);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        cx = w / 2f;
        cy = h / 2f;
        r = Math.min(w, h) * 0.44f;

        sweepShader = new SweepGradient(cx, cy,
                new int[]{Color.TRANSPARENT, Color.TRANSPARENT, alpha(accent, 120)},
                new float[]{0f, 0.65f, 1f});
        sweepPaint.setShader(sweepShader);

        glowPaint.setShader(new RadialGradient(cx, cy, r * 0.75f,
                alpha(accent, 85), Color.TRANSPARENT, Shader.TileMode.CLAMP));
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(9000);
        animator.setInterpolator(new LinearInterpolator());
        animator.setRepeatCount(ValueAnimator.INFINITE);
        animator.addUpdateListener(a -> {
            phase = (float) a.getAnimatedValue();
            invalidate();
        });
        animator.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (animator != null) {
            animator.cancel();
            animator = null;
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (r <= 0) return;

        // ambient glow
        canvas.drawCircle(cx, cy, r * 0.75f, glowPaint);

        // concentric rings
        canvas.drawCircle(cx, cy, r, ring);
        canvas.drawCircle(cx, cy, r * 0.72f, ring);
        canvas.drawCircle(cx, cy, r * 0.44f, ring);

        // outer tick marks (slowly counter-rotating)
        float tickRot = -phase * TWO_PI * 0.25f;
        for (int i = 0; i < 72; i++) {
            float ang = tickRot + i * TWO_PI / 72f;
            float len = (i % 6 == 0) ? 0.09f : 0.045f;
            float c = (float) Math.cos(ang), s = (float) Math.sin(ang);
            canvas.drawLine(cx + c * r * 1.04f, cy + s * r * 1.04f,
                    cx + c * r * (1.04f + len), cy + s * r * (1.04f + len), tick);
        }

        // radar sweep
        sweepMatrix.setRotate(phase * 360f, cx, cy);
        sweepShader.setLocalMatrix(sweepMatrix);
        canvas.drawCircle(cx, cy, r, sweepPaint);

        // orbiting data nodes
        float[] orbit = {1.0f, 0.72f, 0.44f};
        float[] speed = {1f, -1.6f, 2.4f};
        for (int i = 0; i < 3; i++) {
            float ang = phase * TWO_PI * speed[i] + i * 2.1f;
            float nx = cx + (float) Math.cos(ang) * r * orbit[i];
            float ny = cy + (float) Math.sin(ang) * r * orbit[i];
            node.setColor(alpha(cyan, 70));
            canvas.drawCircle(nx, ny, 6f * density, node);
            node.setColor(cyan);
            canvas.drawCircle(nx, ny, 2.6f * density, node);
        }

        drawCrop(canvas);
    }

    /** Crop glyph drawn in a 100x100 box centred on the view. */
    private void drawCrop(Canvas canvas) {
        float pulse = 0.5f + 0.5f * (float) Math.sin(phase * TWO_PI * 3f);
        float scale = r / 52f;

        canvas.save();
        canvas.translate(cx, cy + r * 0.10f);
        canvas.scale(scale, scale);

        // soil strata pad
        fill.setColor(Color.parseColor("#2A1B0F"));
        canvas.drawOval(-20f, 26f, 20f, 38f, fill);
        fill.setColor(Color.parseColor("#4A3220"));
        canvas.drawOval(-22f, 21f, 22f, 34f, fill);
        fill.setColor(Color.parseColor("#7A552F"));
        canvas.drawOval(-24f, 15f, 24f, 29f, fill);
        line.setStrokeWidth(1.3f);
        line.setColor(accent);
        canvas.drawOval(-24f, 15f, 24f, 29f, line);

        // stem
        stem.reset();
        stem.moveTo(0f, 22f);
        stem.cubicTo(0f, 10f, 1f, -2f, 0f, -20f);
        line.setStrokeWidth(2.8f);
        canvas.drawPath(stem, line);

        // leaves
        leafL.reset();
        leafL.moveTo(0f, 8f);
        leafL.cubicTo(-9f, 8f, -16f, 3f, -18f, -6f);
        leafL.cubicTo(-9f, -6f, -1f, -2f, 0f, 8f);
        leafL.close();
        leafR.reset();
        leafR.moveTo(0f, 2f);
        leafR.cubicTo(10f, 2f, 18f, -4f, 20f, -14f);
        leafR.cubicTo(10f, -14f, 1f, -9f, 0f, 2f);
        leafR.close();
        fill.setColor(alpha(accent, 200 + (int) (55 * pulse)));
        canvas.drawPath(leafL, fill);
        canvas.drawPath(leafR, fill);

        // crop head
        bud.reset();
        bud.moveTo(0f, -18f);
        bud.cubicTo(-5f, -24f, -5f, -30f, 0f, -38f);
        bud.cubicTo(5f, -30f, 5f, -24f, 0f, -18f);
        bud.close();
        fill.setColor(Color.parseColor("#D6FFE9"));
        canvas.drawPath(bud, fill);

        // data nodes on the plant
        float[][] pts = {{20f, -14f}, {-18f, -6f}, {0f, -38f}};
        for (float[] p : pts) {
            node.setColor(alpha(cyan, 40 + (int) (60 * pulse)));
            canvas.drawCircle(p[0], p[1], 4.2f + 2.5f * pulse, node);
            node.setColor(cyan);
            canvas.drawCircle(p[0], p[1], 1.9f, node);
        }
        canvas.restore();
    }
}
