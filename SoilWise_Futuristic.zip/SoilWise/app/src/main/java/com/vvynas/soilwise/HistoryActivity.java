package com.vvynas.soilwise;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.vvynas.soilwise.util.Prefs;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class HistoryActivity extends BaseActivity {

    private final List<String> labels = new ArrayList<>();
    private JSONArray data = new JSONArray();
    private ArrayAdapter<String> adapter;
    private View tvEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        initToolbar(R.string.title_history, true);

        tvEmpty = findViewById(R.id.tvEmpty);
        ListView list = findViewById(R.id.list);
        adapter = new ArrayAdapter<>(this, R.layout.item_row, R.id.tvRowText, labels);
        list.setAdapter(adapter);
        list.setOnItemClickListener((p, v, pos, id) -> {
            JSONObject o = data.optJSONObject(pos);
            if (o == null) return;
            new MaterialAlertDialogBuilder(this).setTitle(o.optString("title"))
                    .setMessage(o.optString("body"))
                    .setPositiveButton(R.string.close, null).show();
        });

        findViewById(R.id.btnClear).setOnClickListener(v ->
                new MaterialAlertDialogBuilder(this).setMessage(R.string.clear_confirm)
                        .setNegativeButton(R.string.cancel, null)
                        .setPositiveButton(R.string.delete, (d, w) -> {
                            Prefs.clearHistory(this);
                            refresh();
                        }).show());
        refresh();
    }

    private void refresh() {
        data = Prefs.history(this);
        labels.clear();
        DateFormat df = DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT);
        for (int i = 0; i < data.length(); i++) {
            JSONObject o = data.optJSONObject(i);
            if (o != null) labels.add(df.format(new Date(o.optLong("t"))) + "\n" + o.optString("title"));
        }
        adapter.notifyDataSetChanged();
        tvEmpty.setVisibility(labels.isEmpty() ? View.VISIBLE : View.GONE);
    }
}
