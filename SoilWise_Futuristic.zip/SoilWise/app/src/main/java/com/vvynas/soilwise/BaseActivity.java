package com.vvynas.soilwise;

import android.content.res.Configuration;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.google.android.material.appbar.MaterialToolbar;
import com.vvynas.soilwise.util.Net;
import com.vvynas.soilwise.util.Prefs;

public abstract class BaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setTheme(themeRes());   // must run before super.onCreate
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        boolean night = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                == Configuration.UI_MODE_NIGHT_YES;
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        c.setAppearanceLightStatusBars(!night);
        c.setAppearanceLightNavigationBars(!night);
    }

    private int themeRes() {
        switch (Prefs.theme(this)) {
            case "green": return R.style.Theme_SoilWise_Green;
            case "earth": return R.style.Theme_SoilWise_Earth;
            default: return R.style.Theme_SoilWise_Blue;
        }
    }

    protected void initToolbar(@StringRes int title, boolean up) {
        MaterialToolbar tb = findViewById(R.id.toolbar);
        setSupportActionBar(tb);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle(title);
            getSupportActionBar().setDisplayHomeAsUpEnabled(up);
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    protected boolean alive() {
        return !isFinishing() && !isDestroyed();
    }

    /** Run work off the UI thread; callbacks are skipped if the screen is gone. */
    protected <T> void bg(Net.Task<T> task, Net.Ok<T> ok, Net.Err err) {
        Net.async(task, v -> { if (alive()) ok.run(v); }, m -> { if (alive()) err.run(m); });
    }

    protected void toast(@StringRes int res) { Toast.makeText(this, res, Toast.LENGTH_LONG).show(); }
    protected void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
