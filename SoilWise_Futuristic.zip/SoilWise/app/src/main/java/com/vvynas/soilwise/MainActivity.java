package com.vvynas.soilwise;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.vvynas.soilwise.util.AiClient;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initToolbar(R.string.app_name, false);

        open(R.id.btnAnalyze, AnalyzeActivity.class);
        open(R.id.btnWeather, WeatherActivity.class);
        open(R.id.btnAdvisor, AdvisorActivity.class);
        open(R.id.btnNews, NewsActivity.class);
        open(R.id.btnHistory, HistoryActivity.class);
        open(R.id.btnSettings, SettingsActivity.class);

        if (savedInstanceState == null) intro();
    }

    /** Staggered rise-and-fade entrance for the module cards. */
    private void intro() {
        int[] ids = {R.id.btnAnalyze, R.id.btnWeather, R.id.btnAdvisor,
                R.id.btnNews, R.id.btnHistory, R.id.btnSettings};
        for (int i = 0; i < ids.length; i++) {
            View v = findViewById(ids[i]);
            v.setAlpha(0f);
            v.setTranslationY(56f);
            v.animate().alpha(1f).translationY(0f)
                    .setStartDelay(150L + i * 80L).setDuration(460L).start();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean missing = !AiClient.isConfigured(this);
        findViewById(R.id.tvKeyWarning).setVisibility(missing ? View.VISIBLE : View.GONE);
        ((TextView) findViewById(R.id.tvStatus)).setText(missing ? R.string.status_offline : R.string.status_online);
    }

    private void open(int buttonId, Class<?> target) {
        findViewById(buttonId).setOnClickListener(v -> startActivity(new Intent(this, target)));
    }
}
